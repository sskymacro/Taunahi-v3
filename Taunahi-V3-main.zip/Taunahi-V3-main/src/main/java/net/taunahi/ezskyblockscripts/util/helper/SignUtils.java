package net.taunahi.ezskyblockscripts.util.helper;

import lombok.Getter;
import lombok.Setter;

public class SignUtils {

    @Setter
    @Getter
    private static String textToWriteOnString = "";
}
